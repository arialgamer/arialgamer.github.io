Arial Gamer press kit
https://arialgamer.com.br/press/

You may use these images to write about or feature our games and apps: Deicida, Rota Estelar, Vôlei Total, Gol de Placa, Xodó, Esconde-Esconde, Gelada and Acervo.
Gameplay videos are on each game page and in the press kit page.
Contact: arial83gamer@gmail.com
