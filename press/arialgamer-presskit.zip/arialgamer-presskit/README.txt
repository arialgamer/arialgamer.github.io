Arial Gamer press kit
https://arialgamer.com.br/press/

You may use these images and videos to write about or feature Gelada, Esconde-Esconde and Gol de Placa.
Contact: arial83gamer@gmail.com
